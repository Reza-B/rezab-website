export interface INavItem {
	title: string;
	path: string;
}
